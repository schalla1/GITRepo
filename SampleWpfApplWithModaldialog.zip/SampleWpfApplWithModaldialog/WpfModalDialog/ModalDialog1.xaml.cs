﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using System.Windows.Threading;

namespace Technewlogic.Samples.WpfModalDialog
{
	/// <summary>
	/// Interaction logic for ModalDialog.xaml
	/// </summary>
	public partial class ModalDialog1 : UserControl
	{
		public ModalDialog1()
		{
			InitializeComponent();
			Visibility = Visibility.Hidden;
		}

		private bool _hideRequest = false;
		private bool _result = false;
		private UIElement _parent;

		public void SetParent(UIElement parent)
		{
			_parent = parent;
		}

		#region Message

		public string Message1
		{
			get { return (string)GetValue(MessageProperty1); }
			set { SetValue(MessageProperty1, value); }
		}

		// Using a DependencyProperty as the backing store for Message.
		// This enables animation, styling, binding, etc...
		public static readonly DependencyProperty MessageProperty1 =
			DependencyProperty.Register(
				"Message1", typeof(string), typeof(ModalDialog), new UIPropertyMetadata(string.Empty));

		#endregion

		public bool ShowHandlerDialog1(string message)
		{
			Message1 = message;
			Visibility = Visibility.Visible;

			_parent.IsEnabled = false;

			_hideRequest = false;
			while (!_hideRequest)
			{
				// HACK: Stop the thread if the application is about to close
				if (this.Dispatcher.HasShutdownStarted ||
					this.Dispatcher.HasShutdownFinished)
				{
					break;
				}

				// HACK: Simulate "DoEvents"
				this.Dispatcher.Invoke(
					DispatcherPriority.Background,
					new ThreadStart(delegate { }));
				Thread.Sleep(20);
			}

			return _result;
		}
		
		private void HideHandlerDialog()
		{
			_hideRequest = true;
			Visibility = Visibility.Hidden;
			_parent.IsEnabled = true;
		}

		private void OkButton_Click(object sender, RoutedEventArgs e)
		{
			_result = true;
			HideHandlerDialog();
		}

		private void CancelButton_Click(object sender, RoutedEventArgs e)
		{
			_result = false;
			HideHandlerDialog();
		}
	}
}
